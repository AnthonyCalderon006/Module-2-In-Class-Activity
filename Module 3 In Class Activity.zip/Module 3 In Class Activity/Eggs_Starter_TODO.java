/*
Module 3 In-Class Activity: METHODS PRACTICE
Program: Eggs.java (Starter with TODOs)

Scenario:
Meadowdale Dairy Farm sells organic brown eggs.
- $3.25 per dozen
- $0.45 per loose egg (not part of a dozen)

Goal:
Prompt the user for the number of eggs and print a full explanation, e.g.:
You ordered 27 eggs. That’s 2 dozen at $3.25 per dozen and 3 loose eggs at $0.45 each for a total of $7.85.

Instructions:
Complete the TODOs. Keep your methods small and focused.
*/

import java.util.Scanner;

public class Eggs_Starter_TODO {

    private static final double PRICE_PER_DOZEN = 3.25;
    private static final double PRICE_PER_LOOSE_EGG = 0.45;

    public static int calculateDozens(int eggs) {
        return eggs / 12;
    }

    public static int calculateLooseEggs(int eggs) {
        return eggs % 12;
    }

    public static double calculateTotalCost(int dozens, int looseEggs) {
        return (dozens * PRICE_PER_DOZEN) + (looseEggs * PRICE_PER_LOOSE_EGG);
    }

    public static String buildExplanation(int eggs, int dozens, int looseEggs, double total) {
        return "You ordered " + eggs + " eggs. That's " + dozens + " dozen at $"
                + String.format("%.2f", PRICE_PER_DOZEN)
                + " per dozen and " + looseEggs + " loose eggs at $"
                + String.format("%.2f", PRICE_PER_LOOSE_EGG)
                + " each for a total of $"
                + String.format("%.2f", total) + ".";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of eggs in the order: ");
        int eggs = input.nextInt();

        if (eggs < 0) {
            System.out.println("Error: Number of eggs cannot be negative.");
            input.close();
            return;
        }

        int dozens = calculateDozens(eggs);
        int looseEggs = calculateLooseEggs(eggs);
        double totalCost = calculateTotalCost(dozens, looseEggs);

        String explanation = buildExplanation(eggs, dozens, looseEggs, totalCost);
        System.out.println(explanation);

        input.close();
    }
}

