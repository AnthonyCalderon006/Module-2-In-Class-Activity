import java.util.Scanner;

/*
Module 3 In-Class Activity: METHODS PRACTICE
Program: Eggs.java (Starter with TODOs)

Scenario:
Meadowdale Dairy Farm sells organic brown eggs.
- $3.25 per dozen
- $0.45 per loose egg (not part of a dozen)

Goal:
Prompt the user for the number of eggs and print a full explanation, e.g.:
You ordered 27 eggs. That’s 2 dozen at $3.25 per dozen and 3 loose eggs at $0.45 each for a total of $7.85.

Instructions:
Complete the TODOs. Keep your methods small and focused.
*/
/*
public class Eggs_Starter_TODO {

    // TODO 1: Create constants for prices:
    private static final double PRICE_PER_DOZEN = 3.25;
    private static final double PRICE_PER_LOOSE_EGG = 0.45;

    // TODO 2: Create a method named calculateDozens(int eggs)
    // It should return how many full dozens are in the order.
    public static int calculateDozens(int eggs){
        return eggs/12;
    }

    // TODO 3: Create a method named calculateLooseEggs(int eggs)
    // It should return how many eggs are NOT part of a full dozen.
    public static int calculateLosses(int eggs){
        return eggs%10;
    }

    // TODO 4: Create a method named calculateTotalCost(int dozens, int looseEggs)
    // It should return the total cost as a double.
    public static double calculateTotalCost(int dozens, int lossesEggs){
        return (dozens * PRICE_PER_DOZEN) + (lossesEggs * PRICE_PER_LOOSE_EGG);
    }

    // TODO 5: Create a method named buildExplanation(int eggs, int dozens, int looseEggs, double total)
    // It should return the full explanation string to print.
    public static String bulidExplanation(int eggs, int dozens, int losseEggs, double total){
        return  "You ordered " + eggs + "eggs. that's " + dozens + "dozen at $" +String.format("%.2f",PRICE_PER_DOZEN)
                + "per dozen and " + losseEggs + "loose eggs at $ " + String.format("%.2f", PRICE_PER_LOOSE_EGG)
                + "each of a total of $" + totalFormatted + ".";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of eggs in the order: ");
        int eggs = input.nextInt();
        // TODO 6: Read the number of eggs (int). Validate: eggs >= 0.
        if (eggs < 0); //print an error and exit.
        System.out.println("Error: Number of eggs cannot be negative.");
        input.close();
        return;
        // TODO 7: Use your methods to compute:
        // dozens, looseEggs, totalCost, explanation
        int dozens = calculateDozens(eggs);
        int loosesEggs = calculateLosses(eggs);
        double totalCost = calculateTotalCost(dozens, loosesEggs);

        // TODO 8: Print the explanation
        String explanation = bulidExplanation(eggs, dozens, loosesEggs, totalCost);
        System.out.println(explanation);

        input.close();
    }
}
*/